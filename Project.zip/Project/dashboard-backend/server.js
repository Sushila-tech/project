const mongoose = require('mongoose');
const express = require('express');
const cors = require('cors');
const app = express();
const Data = require('./models/Data'); // Adjust the path as needed

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/assignment', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log('Connected to MongoDB');
}).catch((error) => {
  console.error('Error connecting to MongoDB:', error);
});

app.get('/data', async (req, res) => {
  try {
    const data = await Data.find();
    console.log(data); // Logging to check data
    res.json(data);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

const port = 5000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
