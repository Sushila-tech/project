import React from 'react';

function Filters({ filters, setFilters }) {
  const handleChange = (event) => {
    const { name, value } = event.target;
    setFilters({
      ...filters,
      [name]: value,
    });
  };

  return (
    <div>
      <label>
        End Year:
        <input type="number" name="endYear" value={filters.endYear} onChange={handleChange} />
      </label>
      <label>
        Topic:
        <input type="text" name="topic" value={filters.topic} onChange={handleChange} />
      </label>
      {/* Add more filters as needed */}
    </div>
  );
}

export default Filters;
