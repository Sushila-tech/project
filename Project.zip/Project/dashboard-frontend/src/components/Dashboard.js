import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Filters from './Filters';
import ChartComponent from './ChartComponent';

function Dashboard() {
  const [data, setData] = useState([]);
  const [filters, setFilters] = useState({
    endYear: '',
    topic: '',
    // Add more filter states as needed
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/data');
        setData(response.data);
      } catch (error) {
        console.error('Error fetching data', error);
      }
    };

    fetchData();
  }, []);

  const filteredData = data.filter(item => {
    return (!filters.endYear || item.end_year === parseInt(filters.endYear)) &&
    (!filters.topic || item.topic.includes(filters.topic));
  });

  return (
    <div>
      <Filters filters={filters} setFilters={setFilters} /><br/>
      <ChartComponent data={filteredData} />
    </div>
  );
}

export default Dashboard;
