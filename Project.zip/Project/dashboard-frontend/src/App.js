// import React from 'react';
// import ChartComponent from './components/ChartComponent';

// function App() {
//   return (
//     <div className="App">
//       <ChartComponent />
//     </div>
//   );
// }

// export default App;

import React from 'react';
import './App.css';
import Dashboard from './components/Dashboard';

function App() {
  return (
    <div className="App">
      <Dashboard />
    </div>
  );
}

export default App;
